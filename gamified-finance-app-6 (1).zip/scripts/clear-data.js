// Clear all stored app data
localStorage.removeItem("finestra_transactions")
localStorage.removeItem("finestra_monthly_budget")
localStorage.removeItem("finestra_subscriptions")
console.log("All app data cleared successfully!")
