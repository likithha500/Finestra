import IntroPage from "@/components/intro-page"

export default function Home() {
  return <IntroPage />
}
